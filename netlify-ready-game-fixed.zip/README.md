# Odd One Out — Netlify Drop package

This project is ready to publish from Netlify Drop without Git, a terminal, environment variables, API keys, or manual database setup.

1. Sign in to Netlify, open the Drag and Drop publisher, and upload `netlify-ready-game.zip` (or unzip it and upload this project folder).
2. Netlify reads the root `netlify.toml`, builds the frontend, and packages `netlify/functions/game.ts` at `/.netlify/functions/game`.
3. Netlify Blobs creates the `odd-one-out-games` store automatically on first function use.

The app polls the function for live room state. Each room is stored in Netlify Blobs with strong consistency; state changes use ETag conditional writes so simultaneous player actions do not overwrite each other.

To play, one person creates a room and shares the six-character code. Other players join from their own devices. Each round goes prompt → private answer → discussion/vote → results. The host advances through five rounds.

The ZIP contains the frontend source, production output, function, helper modules, tests, package manifest, lockfile, and Netlify configuration. It excludes dependency folders and build caches.
